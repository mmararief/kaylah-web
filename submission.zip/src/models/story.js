export class Story {
  constructor(id, name, description, photoUrl, lat, lon) {
    this.id = id;
    this.name = name;
    this.description = description;
    this.photoUrl = photoUrl;
    this.lat = lat;
    this.lon = lon;
  }
}
