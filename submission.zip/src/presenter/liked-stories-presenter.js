import { renderLikedStoriesPage } from '../views/liked-stories-page';

export const handleLikedStoriesPage = () => {
  renderLikedStoriesPage();
}; 