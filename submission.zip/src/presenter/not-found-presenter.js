import { renderNotFoundPage } from '../views/not-found-page';

export const handleNotFoundPage = () => {
  renderNotFoundPage();
}; 