import { handleAddStoryPage } from '../../presenter/add-story-presenter';

export const renderAddStory = () => {
  handleAddStoryPage();
};
